/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_TEST_VINT_H_INCLUDED_
#define _XQC_TEST_VINT_H_INCLUDED_

void xqc_test_vint();

#endif /* _XQC_TEST_VINT_H_INCLUDED_ */
