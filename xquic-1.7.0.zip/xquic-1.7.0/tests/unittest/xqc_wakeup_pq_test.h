/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_WAKEUP_PQ_TEST_H_INCLUDED_
#define _XQC_WAKEUP_PQ_TEST_H_INCLUDED_

void xqc_test_wakeup_pq();

#endif /* _XQC_WAKEUP_PQ_TEST_H_INCLUDED_ */
