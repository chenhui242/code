/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_CRYPTO_TEST_INCLUDE_
#define _XQC_CRYPTO_TEST_INCLUDE_

void xqc_test_crypto();

#endif
