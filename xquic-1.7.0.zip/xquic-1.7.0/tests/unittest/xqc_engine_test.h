/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_ENGINE_TEST_H
#define XQC_ENGINE_TEST_H

void xqc_test_engine_create();
void xqc_test_engine_packet_process();

#endif
