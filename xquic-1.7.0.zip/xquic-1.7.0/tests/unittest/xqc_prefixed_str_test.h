/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_PREFIXED_STR_TEST_H
#define XQC_PREFIXED_STR_TEST_H

void xqc_test_prefixed_str();

#endif
