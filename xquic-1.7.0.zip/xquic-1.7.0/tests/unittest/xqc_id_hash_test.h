/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_ID_HASH_H
#define XQC_ID_HASH_H

void xqc_test_id_hash();

#endif
