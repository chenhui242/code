/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_TLS_TEST_INCLUDE_
#define _XQC_TLS_TEST_INCLUDE_

void xqc_test_tls();

#endif