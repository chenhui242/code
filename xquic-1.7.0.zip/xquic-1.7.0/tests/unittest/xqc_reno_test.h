/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef _XQC_RENO_TEST_H_INCLUDED_
#define _XQC_RENO_TEST_H_INCLUDED_

void xqc_test_reno ();

#endif /* _XQC_RENO_TEST_H_INCLUDED_ */
