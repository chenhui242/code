# Security Policy

## Reporting a Vulnerability

To report a security issue, please email xquic@alibaba-inc.com with a description of the issue, the steps you took to create the issue, affected versions, and, if known, mitigations for the issue. Our vulnerability management team will respond within 3 working days of your email.
