/**
 * @copyright Copyright (c) 2022, Alibaba Group Holding Limited
 */

#ifndef XQC_HQ_CONN_H
#define XQC_HQ_CONN_H

#include "xqc_hq.h"

extern const xqc_conn_callbacks_t hq_conn_callbacks;

#endif